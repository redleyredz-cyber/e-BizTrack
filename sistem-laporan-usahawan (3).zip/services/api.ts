
import { Report } from '../types';

/**
 * PENTING: Gantikan URL di bawah dengan "Web App URL" anda sendiri 
 * dari Google Apps Script (Deploy > New Deployment).
 */
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwO-uyZT4pHGlnjTYI0ncGStkVfly6Z9tLrF5SYxGjkmVdiZlzvFxXF9pDhWFy_44If/exec';

export const ReportService = {
  async fetchReports(): Promise<{ reports: Report[], isLive: boolean }> {
    try {
      // Tambah cache buster untuk mengelakkan data lama dari cache pelayar
      const response = await fetch(`${SCRIPT_URL}?t=${Date.now()}`, {
        method: 'GET',
        redirect: 'follow',
      });

      if (!response.ok) throw new Error('Network response was not ok');
      
      const data = await response.json();
      return { reports: data, isLive: true };
    } catch (error) {
      console.error('Gagal mengambil data dari Google Sheets:', error);
      
      // Ambil dari local storage jika cloud gagal
      const saved = localStorage.getItem('pppk_reports');
      const localData = saved ? JSON.parse(saved) : [];
      return { reports: localData, isLive: false };
    }
  },

  async addReport(report: Report): Promise<boolean> {
    try {
      // POST ke Google Apps Script selalunya perlukan mode: 'no-cors' 
      // supaya pelayar tidak menyekat request tersebut.
      await fetch(SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'addReport',
          report
        }),
      });
      // Kerana mode 'no-cors', kita tidak boleh baca response, 
      // jadi kita anggap berjaya jika tidak masuk ke catch.
      return true;
    } catch (error) {
      console.error('Gagal menghantar laporan ke Google Sheets:', error);
      return false;
    }
  }
};

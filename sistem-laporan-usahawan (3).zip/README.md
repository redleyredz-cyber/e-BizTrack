# Sistem Laporan Usahawan PPPK

Aplikasi ini adalah sistem laporan bulanan untuk kakitangan PPPK. Ia menyokong fungsi PWA (boleh di-install di telefon) dan menggunakan Google Sheets sebagai pangkalan data.

## Cara Publish ke Vercel (Langkah-demi-Langkah)

Vercel memerlukan **Repository URL** dari GitHub. Ikuti langkah ini:

### Langkah 1: Buat Akaun GitHub & Repository
1. Pergi ke [GitHub.com](https://github.com) dan daftar akaun jika belum ada.
2. Tekan butang **"New"** untuk cipta Repository baru.
3. Berikan nama (contoh: `laporan-pppk`).
4. Pilih **Public** dan tekan **"Create repository"**.
5. Salin URL Repository tersebut (contoh: `https://github.com/username/laporan-pppk`). **Inilah URL yang Vercel minta.**

### Langkah 2: Muat Naik Kod ke GitHub
Jika anda menggunakan komputer, cara paling mudah ialah:
1. Di halaman repository GitHub anda, tekan pautan **"uploading an existing file"**.
2. Tarik dan lepaskan (Drag & Drop) semua fail dari projek ini ke dalam kotak tersebut.
3. Tekan **"Commit changes"**.

### Langkah 3: Sambung ke Vercel
1. Pergi ke [Vercel.com](https://vercel.com).
2. Tekan **"Add New"** > **"Project"**.
3. Di bahagian "Import Git Repository", tampal **URL Repository GitHub** anda tadi.
4. Tekan **"Deploy"**.
5. Vercel akan memberikan URL baru (contoh: `https://laporan-pppk.vercel.app`).

### Langkah 4: Install di Telefon
1. Buka URL Vercel anda di telefon.
2. **Android**: Tekan 3 titik > "Install App".
3. **iPhone**: Tekan butang Share > "Add to Home Screen".

---
**Nota Penting:** Pastikan anda telah mengemaskini `SCRIPT_URL` di dalam fail `services/api.ts` dengan URL Google Apps Script anda sendiri supaya data dapat disimpan.

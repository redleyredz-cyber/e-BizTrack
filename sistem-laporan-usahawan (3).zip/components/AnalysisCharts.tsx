
import React, { useMemo } from 'react';
import { Report, Category } from '../types';
import { CATEGORIES } from '../constants';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { TrendingUp, Users, ShoppingBag, Salad } from 'lucide-react';

interface AnalysisChartsProps {
  reports: Report[];
}

const COLORS = ['#3b82f6', '#f59e0b', '#8b5cf6'];

const AnalysisCharts: React.FC<AnalysisChartsProps> = ({ reports }) => {
  const statsByCategory = useMemo(() => {
    return CATEGORIES.map(cat => {
      const catReports = reports.filter(r => r.category === cat);
      return {
        name: cat,
        totalIncome: catReports.reduce((acc, curr) => acc + curr.netIncome, 0),
        count: catReports.length,
        avgIncome: catReports.length ? catReports.reduce((acc, curr) => acc + curr.netIncome, 0) / catReports.length : 0
      };
    });
  }, [reports]);

  const totalRevenue = reports.reduce((acc, curr) => acc + curr.netIncome, 0);

  const getIcon = (cat: Category) => {
    switch (cat) {
      case 'Usahawan': return <ShoppingBag className="w-5 h-5" />;
      case 'Agromakanan': return <Salad className="w-5 h-5" />;
      case 'Agro TS': return <Users className="w-5 h-5" />;
    }
  };

  const getBgColor = (cat: Category) => {
    switch (cat) {
      case 'Usahawan': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'Agromakanan': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'Agro TS': return 'bg-purple-50 text-purple-700 border-purple-100';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {statsByCategory.map((stat, i) => (
          <div key={stat.name} className={`p-6 rounded-2xl border shadow-sm ${getBgColor(stat.name as Category)}`}>
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-white/50 rounded-lg">{getIcon(stat.name as Category)}</div>
              <span className="text-xs font-bold uppercase tracking-wider opacity-70">{stat.name}</span>
            </div>
            <p className="text-sm opacity-80 mb-1">Jumlah Pendapatan Bersih</p>
            <p className="text-2xl font-black mb-4">RM {stat.totalIncome.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            <div className="flex justify-between text-xs font-bold">
              <span>{stat.count} Laporan</span>
              <span>Purata: RM {stat.avgIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Income by Category Bar Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" /> Agihan Pendapatan Bersih
          </h3>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statsByCategory}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 500 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: any) => [`RM ${value.toLocaleString()}`, 'Pendapatan']}
                />
                <Bar dataKey="totalIncome" radius={[6, 6, 0, 0]} barSize={50}>
                  {statsByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Distribution Pie Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-purple-600" /> Peratusan Laporan Dihantar
          </h3>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statsByCategory}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={8}
                  dataKey="count"
                >
                  {statsByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisCharts;
